function calculateEvolves(candyHold,candyReq) {
              
              //Calculates how many candy will be unused during first round of evolutions
              var candyRemainder = candyHold % candyReq;
              
              //Calculates how many evolutions can be done with initial settings
              var evolutions = (candyHold-candyRemainder)/candyReq;
              
              //Calculates how many candy will be left over after 1st pass of evolutions, including candy gained
              var candyPlus = candyRemainder + evolutions ;
              
              //Tracks total number of evolutions possible
              var totalEvolutions = evolutions;
              
              while(candyRemainder != 0 && candyPlus >= candyReq){
                     candyRemainder = candyPlus % candyReq;
                     
                     evolutions = (candyPlus-candyRemainder)/candyReq;
                     
                     candyPlus = candyRemainder + evolutions;
                     
                     totalEvolutions = totalEvolutions + evolutions;
                     
              }
              
              var maxEvolutions = totalEvolutions;
              
              $("#results").append(maxEvolutions);
       }
